# m-rdgw-az
RDGW Module using Availability Zones

This module will deploy 1 or more Azure Windows VMs to an availability zone behind a zone redundant Standard load balancer.  
This can only be used in regions that support Availability zones.  This module will deploy all the required networking for the environment as well.
